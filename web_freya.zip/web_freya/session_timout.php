<?php
//inisialisasi session
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
// menentukan waktu timeout dalam detik
$timeout = 100 * 60; // 1 menit dalam detik
$logout = "../login.php";

// Mengecek apakah sesi sudah dimulai
if (isset($_SESSION['start_session'])) {
    $elapsed_time = time() - $_SESSION['start_session'];
    
    // Mengecek apakah waktu sesi telah habis
    if ($elapsed_time >= $timeout) {
        session_destroy();
        echo "<script type='text/javascript'>alert('Sesi telah berakhir');window.location='$logout'</script>";
        exit();
    }
} else {
    // Jika sesi belum dimulai, atur waktu mulai sesi
    $_SESSION['start_session'] = time();
}

// Mengecek apakah username ada di dalam sesi
if (!isset($_SESSION['username'])) {
    echo "<script>
        alert('Anda harus LOGIN terlebih dahulu !!!');
        window.location.assign('../login.php');
    </script>";
    exit();
}
?>