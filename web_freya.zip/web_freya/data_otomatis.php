<?php
    include "database/koneksi.php";

    $query = "SELECT nama, nim, prodi FROM mahasiswa";
    $sqlotomatis = mysqli_query($conn, $query);

?>