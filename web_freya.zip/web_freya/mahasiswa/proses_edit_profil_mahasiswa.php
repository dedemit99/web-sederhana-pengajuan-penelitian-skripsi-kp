<?php
include '../session_username.php';
include '../database/koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST['aksi'] == 'edit') {
    $nim = mysqli_real_escape_string($conn, $_POST['nim']);
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $prodi = mysqli_real_escape_string($conn, $_POST['prodi']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $jenis_kelamin = mysqli_real_escape_string($conn, $_POST['jenis_kelamin']);
    $telp = mysqli_real_escape_string($conn, $_POST['telp']);
    $alamat = mysqli_real_escape_string($conn, $_POST['alamat']);
    $kota = mysqli_real_escape_string($conn, $_POST['kota']);
    $provinsi = mysqli_real_escape_string($conn, $_POST['provinsi']);
    $kodepos = mysqli_real_escape_string($conn, $_POST['kodepos']);

    $queryShow = "SELECT * FROM mahasiswa WHERE nim='$nim'";
    $sqlShow = mysqli_query($conn, $queryShow);
    $result = mysqli_fetch_assoc($sqlShow);

    if ($_FILES['foto']['name'] == "") {
        $foto = $result['foto'];
    } else {
        $foto = $_FILES['foto']['name'];
        unlink("../images/" . $result['foto']);
        move_uploaded_file($_FILES['foto']['tmp_name'], '../images/' . $_FILES['foto']['name']);
    }

    $query = "UPDATE mahasiswa SET nim='$nim', nama='$nama', prodi='$prodi', email='$email', jenis_kelamin='$jenis_kelamin', telp='$telp', alamat='$alamat', kota='$kota', provinsi='$provinsi', kode_pos='$kodepos', foto='$foto' WHERE username='$username'";
    $sql = mysqli_query($conn, $query); 

    if ($sql) {
        header("location: index.profil.php");
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }
}
?>
