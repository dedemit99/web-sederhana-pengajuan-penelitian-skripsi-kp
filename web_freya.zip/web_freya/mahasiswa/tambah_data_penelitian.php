<?php
include "../database/koneksi.php";
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['aksi']) && $_POST['aksi'] == 'simpan_penelitian') {
    // Ambil NIM dari form
    $nim = $_POST['nim'];

    // Ambil data mahasiswa berdasarkan nim
    $query_mahasiswa = "SELECT id_mahasiswa, nama, nim, prodi FROM mahasiswa WHERE nim = ?";
    $stmt_mahasiswa = mysqli_prepare($conn, $query_mahasiswa);
    if ($stmt_mahasiswa === false) {
        die('Prepare failed: ' . htmlspecialchars(mysqli_error($conn)));
    }
    mysqli_stmt_bind_param($stmt_mahasiswa, "s", $nim);
    mysqli_stmt_execute($stmt_mahasiswa);
    $result_mahasiswa = mysqli_stmt_get_result($stmt_mahasiswa);

    if ($result_mahasiswa === false) {
        die('Get result failed: ' . htmlspecialchars(mysqli_error($conn)));
    }

    if (mysqli_num_rows($result_mahasiswa) > 0) {
        $row_mahasiswa = mysqli_fetch_assoc($result_mahasiswa);
        $id_mahasiswa = $row_mahasiswa['id_mahasiswa'];
        $nama = $row_mahasiswa['nama'];
        $nim = $row_mahasiswa['nim'];
        $prodi = $row_mahasiswa['prodi'];
        echo "Nama: " . $nama . "<br>"; // Debugging
        echo "NIM: " . $nim . "<br>"; // Debugging
        echo "Prodi: " . $prodi . "<br>"; // Debugging
    } else {
        echo "Data mahasiswa tidak ditemukan.";
        exit;
    }

    $judul = $_POST['judul'];
    $tanggal_pengajuan = $_POST['tanggal_pengajuan'];
    $latarbelakang = $_POST['latarbelakang'];

    // Penanganan upload file
    $target_dir = "../pdfs/";
    $target_file = $target_dir . basename($_FILES["surat_penelitian"]["name"]);
    $uploadOk = 1;
    $fileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Cek apakah file sudah ada
    if (file_exists($target_file)) {
        echo "Maaf, file sudah ada.";
        $uploadOk = 0;
    }

    // Cek ukuran file
    if ($_FILES["surat_penelitian"]["size"] > 5000000) { // 5 MB
        echo "Maaf, file Anda terlalu besar.";
        $uploadOk = 0;
    }

    // Hanya mengizinkan format file tertentu
    $allowedFormats = array('pdf', 'doc', 'docx');
    if (!in_array($fileType, $allowedFormats)) {
        echo "Maaf, hanya file PDF, DOC, DOCX yang diizinkan.";
        $uploadOk = 0;
    }

    // Cek apakah $uploadOk diset menjadi 0 karena kesalahan
    if ($uploadOk == 0) {
        echo "Maaf, file Anda tidak berhasil diupload.";
    } else {
        // Jika semua oke, coba upload file
        if (move_uploaded_file($_FILES["surat_penelitian"]["tmp_name"], $target_file)) {
            $sql = "INSERT INTO penelitian (judul, tanggal_pengajuan, deskripsi, surat, id_mahasiswa) VALUES (?, ?, ?, ?, ?)";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "ssssi", $judul, $tanggal_pengajuan, $latarbelakang, $target_file, $id_mahasiswa);

            if (mysqli_stmt_execute($stmt)) {
                echo "<script>alert('Pengajuan Penelitian Berhasil.'); window.location.href='penelitian.php';</script>";
            } else {
                echo "Error: " . mysqli_stmt_error($stmt);
            }

            mysqli_stmt_close($stmt);
        } else {
            echo "Maaf, terjadi kesalahan saat mengupload file Anda.";
        }
    }

    mysqli_stmt_close($stmt_mahasiswa);
    mysqli_close($conn);
}
?>
