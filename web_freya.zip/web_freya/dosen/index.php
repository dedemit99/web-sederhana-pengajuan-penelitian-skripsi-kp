<?
include '../session_timout.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
</head>
<body id="page-top">
<?php
if(isset($_GET['page'])){
    $page = ['page'];

    switch($page){
      case 'skripsi':
        include "skripsi.php";
        break;
      case 'dashboard':
        include "dashboard.php";
        break;
      case 'kp':
        include "kp.php";
        break;
      case 'penelitian':
        include "penelitian.php";
        break;
      default:
      echo "<center><h3>Maaf. Halaman tidak tersedia !</h3></center>";
    }
  }else{
    include "dashboard.php";
  }
?>
</div>
</body>
</html>