<?php
include '../session_username.php';
include '../database/koneksi.php';

if (!isset($_GET['username'])) {
    header("location: dashboard.php");
    exit;
}

$username = $_GET['username'];
$data = mysqli_query($conn, "SELECT * FROM dosen WHERE username = '$username'");
$d = mysqli_fetch_array($data);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <link href="../images/logoutama-.png" rel="icon" />
    <title>Edit Profil</title>
    <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css" />
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="../css/ruang-admin.min.css" rel="stylesheet" />
</head>
<body id="page-top">
    <div id="wrapper">
        <!-- Sidebar -->
        <ul class="navbar-nav sidebar sidebar-light accordion" id="accordionSidebar">
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="dashboard.php">
                <div class="sidebar-brand-icon">
                    <img src="../images/logoutama-.png" />
                </div>
                <div class="sidebar-brand-text mx-3">Web Freya</div>
            </a>
            <hr class="sidebar-divider my-0" />
            <li class="nav-item active">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <hr class="sidebar-divider" />
            <div class="sidebar-heading">Category</div>
            <li class="nav-item">
                <a class="nav-link collapsed" href="skripsi.php?page=skripsi">
                    <i class="far fa-fw fa-window-maximize"></i>
                    <span>Skripsi</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link collapsed" href="kp.php?page=kp">
                    <i class="fab fa-fw fa-wpforms"></i>
                    <span>Kerja Praktek</span>
                </a>
                <div id="collapseForm" class="collapse" aria-labelledby="headingForm" data-parent="#accordionSidebar">
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link collapsed" href="penelitian.php?page=penelitian">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Penelitian</span>
                </a>
            </li>
            <hr class="sidebar-divider" />
            <div class="version" id="version-ruangadmin"></div>
        </ul>
        <!-- Sidebar -->
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <!-- TopBar -->
                <nav class="navbar navbar-expand navbar-light bg-navbar topbar mb-4 static-top">
                    <button id="sidebarToggleTop" class="btn btn-link rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-search fa-fw"></i>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                                <form class="navbar-search">
                                    <div class="input-group">
                                        <input type="text" class="form-control bg-light border-1 small" placeholder="What do you want to look for?" aria-label="Search" aria-describedby="basic-addon2" style="border-color: #3f51b5" />
                                        <div class="input-group-append">
                                            <button class="btn btn-primary" type="button">
                                                <i class="fas fa-search fa-sm"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </li>
                        <li class="nav-item dropdown no-arrow mx-1">
                            <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-bell fa-fw"></i>
                                <span class="badge badge-danger badge-counter">3+</span>
                            </a>
                            <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="alertsDropdown">
                                <h6 class="dropdown-header">Alerts Center</h6>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="mr-3">
                                        <div class="icon-circle bg-primary">
                                            <i class="fas fa-file-alt text-white"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="small text-gray-500">December 12, 2019</div>
                                        <span class="font-weight-bold">A new monthly report is ready to download!</span>
                                    </div>
                                </a>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="mr-3">
                                        <div class="icon-circle bg-success">
                                            <i class="fas fa-donate text-white"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="small text-gray-500">December 7, 2019</div>
                                        $290.29 has been deposited into your account!
                                    </div>
                                </a>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="mr-3">
                                        <div class="icon-circle bg-warning">
                                            <i class="fas fa-exclamation-triangle text-white"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="small text-gray-500">December 2, 2019</div>
                                        Spending Alert: We've noticed unusually high spending for your account.
                                    </div>
                                </a>
                                <a class="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a>
                            </div>
                        </li>
                        <div class="topbar-divider d-none d-sm-block"></div>
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img class="img-profile rounded-circle" src="../images/boy.png" style="max-width: 60px" />
                                <span class="ml-2 d-none d-lg-inline text-white small"><?= $username; ?></span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="index_profil.php">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Profile
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Settings
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Activity Log
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="../logout.php" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>
                    </ul>
                </nav>
                <!-- Content -->
                <div class="container">
                    <h1 class="text-center">Edit Dosen</h1>
                    <hr>
                    <form action="proses_edit_profil_dosen.php" method="post" enctype="multipart/form-data">
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <tr>
                                    <td><label for="nidn">*NIDN :</label></td>
                                    <td><input value="<?= $d['nidn']; ?>" type="text" name="nidn" placeholder="Masukan NIDN" maxlength="30" required></td>
                                </tr>
                                <tr>
                                    <td><label for="nama">*Nama :</label></td>
                                    <td><input value="<?= $d['nama']; ?>" type="text" name="nama" placeholder="Masukan Nama" maxlength="30" required></td>
                                </tr>
                                <tr>
                                    <td><label for="email">*Email :</label></td>
                                    <td><input value="<?= $d['email']; ?>" type="email" name="email" placeholder="Masukan Email" maxlength="30" required></td>
                                </tr>
                                <tr>
                                    <td><label for="jenis_kelamin">*Jenis Kelamin :</label></td>
                                    <td>
                                        <select name="jenis_kelamin" required>
                                            <option value="">Pilih Jenis Kelamin</option>
                                            <option value="L" <?= ($d['jenis_kelamin'] == 'L') ? 'selected' : ''; ?>>Laki-laki</option>
                                            <option value="P" <?= ($d['jenis_kelamin'] == 'P') ? 'selected' : ''; ?>>Perempuan</option>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <td><label for="telp">*Telp :</label></td>
                                    <td><input value="<?= $d['telp']; ?>" type="text" name="telp" placeholder="Masukan Telp" maxlength="13" required></td>
                                </tr>
                                <tr>
                                    <td><label for="alamat">*Alamat :</label></td>
                                    <td><input value="<?= $d['alamat']; ?>" type="text" name="alamat" placeholder="Masukan Alamat" maxlength="30" required></td>
                                </tr>
                                <tr>
                                    <td><label for="kota">*Kota :</label></td>
                                    <td><input value="<?= $d['kota']; ?>" type="text" name="kota" placeholder="Masukan Kota" maxlength="30" required></td>
                                </tr>
                                <tr>
                                    <td><label for="provinsi">*Provinsi :</label></td>
                                    <td><input value="<?= $d['provinsi']; ?>" type="text" name="provinsi" placeholder="Masukan Provinsi" maxlength="30" required></td>
                                </tr>
                                <tr>
                                    <td><label for="kodepos">*Kode Pos :</label></td>
                                    <td><input value="<?= $d['kode_pos']; ?>" type="text" name="kodepos" placeholder="Masukan Kode Pos" maxlength="6" required></td>
                                </tr>
                                <tr>
                                    <td><label for="foto">*Foto :</label></td>
                                    <td>
                                        <input type="file" name="foto">
                                        <br>
                                        <img src="images/<?= $d['foto']; ?>" width="100">
                                    </td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td><button class="btn btn-primary" type="submit" name="aksi" value="edit">Update</button></td>
                                </tr>
                            </table>
                        </div>
                    </form>
                </div>
            </div>
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span> &copy; 2024 <strong><span>RuangAdmin</span></strong> - All Rights Reserved</span>
                    </div>
                </div>
            </footer>
        </div>
    </div>
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="../js/ruang-admin.min.js"></script>
</body>
</html>
