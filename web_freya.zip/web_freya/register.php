<?php
include 'database/koneksi.php';
session_start();

$error = '';
$validate = '';

if (isset($_POST['submit'])) {
    $username = stripslashes($_POST['username']);
    $username = mysqli_real_escape_string($conn, $username);
    $email = stripslashes($_POST['email']);
    $email = mysqli_real_escape_string($conn, $email);
    $password = stripslashes($_POST['password']);
    $password = mysqli_real_escape_string($conn, $password);
    if (isset($_POST['level'])) {   
        $level = stripslashes($_POST['level']);
        $level = mysqli_real_escape_string($conn, $level);
    } else {
        $level = '';
    }

    if (!empty(trim($username)) && !empty(trim($email)) && !empty(trim($level)) && !empty(trim($password))) {
        if ($password) {
            if (cek_nama($username, $conn) == 0) {
                $pass = password_hash($password, PASSWORD_DEFAULT);
                $query = "INSERT INTO user (username, email, password, level) VALUES ('$username', '$email', '$pass', '$level')";
                $result = mysqli_query($conn, $query);
                if ($result) {
                    $_SESSION['username'] = $username;
                    if ($level == 'dosen') {
                        header('Location: login.php');
                    } elseif ($level == 'mahasiswa') {
                        header('Location: login.php');
                    }
                    exit();
                } else {
                    $error = 'Register User Gagal !!';
                }
            } else {
                $error = 'Username sudah terdaftar !!';
            }
        } else {
            $validate = 'Password tidak sama !!';
        }
    } else {
        $error = 'Data tidak boleh kosong !!';
    }
}

function cek_nama($username, $conn)
{
    $nama = mysqli_real_escape_string($conn, $username);
    $query = "SELECT * FROM user WHERE username = '$nama'";
    if ($result = mysqli_query($conn, $query)) return mysqli_num_rows($result);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
    <meta name="description" content=""/>
    <meta name="author" content=""/>
    <link href="img/logo/logo.png" rel="icon"/>
    <title>Register</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css"/>
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <link href="css/ruang-admin.min.css" rel="stylesheet"/>
</head>
<body class="bg-gradient-login">
<div class="container-login">
    <div class="row justify-content-center">
        <div class="col-xl-5 col-lg-12 col-md-9">
            <div class="card shadow-sm my-5">
                <div class="card-body p-0">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="login-form">
                                <div class="text-center">
                                    <h1 class="h4 text-gray-900 mb-4">Register</h1>
                                </div>
                                <?php if($error != ''){ ?>
                                    <div class="alert alert-danger" role="alert"><?= $error; ?></div>
                                <?php } ?>
                                <form method="POST" action="">
                                    <div class="form-group">
                                        <label>Username</label>
                                        <input type="text" name="username" class="form-control" placeholder="Username" required/>
                                    </div>
                                    <div class="form-group">
                                        <label>Email</label>
                                        <input type="email" name="email" class="form-control" placeholder="Email Address" required/>
                                    </div>
                                    <div class="form-group">
                                        <label>Level</label>
                                        <select class="form-control form-control-sm mb-3" name="level" required>
                                            <option value="dosen">Dosen</option>
                                            <option value="mahasiswa">Mahasiswa</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label>Password</label>
                                        <input type="password" name="password" class="form-control" placeholder="Password" required/>
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" name="submit" class="btn btn-primary btn-block">Register</button>
                                    </div>
                                    <hr/>
                                    <a href="index.html" class="btn btn-google btn-block"><i class="fab fa-google fa-fw"></i> Register with Google</a>
                                    <a href="index.html" class="btn btn-facebook btn-block"><i class="fab fa-facebook-f fa-fw"></i> Register with Facebook</a>
                                </form>
                                <hr/>
                                <div class="text-center">
                                    <a class="font-weight-bold small" href="login.php">Already have an account?</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>
<script src="js/ruang-admin.min.js"></script>
</body>
</html>
