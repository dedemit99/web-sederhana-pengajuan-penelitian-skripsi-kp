Copy code
<?php
include 'database/koneksi.php';
session_start();

$error = '';
$validate = '';

if (isset($_POST['submit'])) {
    $username = stripslashes($_POST['username']);
    $username = mysqli_real_escape_string($conn, $username);
    $password = stripslashes($_POST['password']);
    $password = mysqli_real_escape_string($conn, $password);

    if (!empty(trim($username)) && !empty(trim($password))) {
        $query = "SELECT * FROM user WHERE username = '$username'";
        $result = mysqli_query($conn, $query);

        if ($result) {
            $user = mysqli_fetch_assoc($result);
            if ($user) {
                if (password_verify($password, $user['password'])) {
                    $_SESSION['username'] = $username;
                    $_SESSION['level'] = $user['level'];
                    $_SESSION['id_user'] = $user['id_user']; // Simpan id_user ke dalam sesi

                    if ($user['level'] == 'mahasiswa') {
                        header('Location: mahasiswa/dashboard.php');
                    } elseif ($user['level'] == 'dosen') {
                        header('Location: dosen/dashboard.php');
                    }
                    exit();
                } else {
                    $error = 'Password salah';
                }
            } else {
                $error = 'Username tidak ditemukan';
            }
        } else {
            $error = 'Terjadi kesalahan dalam mengambil data';
        }
    } else {
        $error = 'Username dan password harus diisi';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
    <meta name="description" content=""/>
    <meta name="author" content=""/>
    <link href="img/logo/logo.png" rel="icon"/>
    <title>Login</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css"/>
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <link href="css/ruang-admin.min.css" rel="stylesheet"/>
</head>
<body class="bg-gradient-login">
<div class="container-login">
    <div class="row justify-content-center">
        <div class="col-xl-4 col-lg-12 col-md-9">
            <div class="card shadow-sm my-5">
                <div class="card-body p-0">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="login-form">
                                <div class="text-center">
                                    <h1 class="h4 text-gray-900 mb-4">Login</h1>
                                </div>
                                <div class="text-center">
                                    <img src="images/logoutama-.png" alt="" width="150">
                                </div>
                                <div class="text-center">
                                    <p>Login Menggunakan E-Mail atau Username Anda</p>
                                </div>
                                <?php if($error != ''){ ?>
                                    <div class="alert alert-danger" role="alert"><?= $error; ?></div>
                                <?php } ?>
                                <form method="POST" action="">
                                    <div class="form-group">
                                        <input type="text" name="username" class="form-control" placeholder="Username" required/>
                                    </div>
                                    <div class="form-group">
                                        <input type="password" name="password" class="form-control" placeholder="Password" required/>
                                    </div>
                                    <div class="form-group">
                                        <div class="custom-control custom-checkbox small" style="line-height: 1.5rem;">
                                            <input type="checkbox" class="custom-control-input" id="customCheck">
                                            <label class="custom-control-label" for="customCheck">Remember
                                                Me</label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" name="submit" class="btn btn-primary btn-block">Sign In</button>
                                    </div>
                                    <hr/>
                                    <a href="#" class="btn btn-google btn-block">
                                        <i class="fab fa-google fa-fw"></i> Login with Google
                                    </a>
                                    <a href="#" class="btn btn-facebook btn-block">
                                        <i class="fab fa-facebook-f fa-fw"></i> Login with Facebook
                                    </a>
                                </form>
                                <hr/>
                                <div class="text-center">
                                    <a class="font-weight-bold small" href="register.php">Create an Account!</a>
                                </div>
                                <div class="text-center">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>
<script src="js/ruang-admin.min.js"></script>
</body>
</html>
