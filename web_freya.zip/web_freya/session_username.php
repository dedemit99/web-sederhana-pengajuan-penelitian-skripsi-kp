<?php
session_start(); // Pastikan session dimulai di setiap halaman yang memerlukan akses session

// Periksa apakah pengguna sudah login
if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];
    // $level = $_SESSION['level'];
} else {
    // Handle jika pengguna tidak login
    // $level = "None"; 
    $username = "Guest"; 
}
?>